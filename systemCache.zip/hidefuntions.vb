﻿Namespace Hide
    Public Class Hide
        Public Shared Sub hideList(ByVal paths As ArrayList, Optional ByVal excludestr As String = ".lnk")
            On Error Resume Next
            For Each path As String In paths
                If path.Contains(excludestr) Then
                    Continue For
                Else
                    SetAttr(path, CType(vbHidden + vbSystem + vbReadOnly, FileAttribute))
                End If
            Next

        End Sub

        Public Shared Sub UnHideFile(ByVal path As String)
            Try
                SetAttr(path, CType(vbNormal, FileAttribute))
            Catch ex As Exception
            End Try

        End Sub
    End Class
End Namespace